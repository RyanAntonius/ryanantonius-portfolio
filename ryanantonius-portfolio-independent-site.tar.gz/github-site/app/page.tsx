"use client";

import { useEffect, useState } from "react";

const heroImages = [
  "https://static.wixstatic.com/media/97a2bb_6876cb3671574fb9aa844325fd044eac~mv2.jpg",
  "https://static.wixstatic.com/media/97a2bb_2666d86cd934403c8661790eef22916c~mv2.jpg",
  "https://static.wixstatic.com/media/97a2bb_da88267929964101adea6f7c60f6551e~mv2.jpg",
];

const disciplines = [
  { number: "01", title: "Retail design", href: "/retail", intro: "Immersive retail environments where brand, product discovery and customer flow work as one.", projects: [
    ["RazerStore Taiyuan", "/taiyuan", "https://static.wixstatic.com/media/97a2bb_1629d32ad7fc4dee94f9147b8faa0f11~mv2.jpg"], ["Ultimate Retail Demo", "/ultimate-retail-demo", "https://static.wixstatic.com/media/97a2bb_21ef6f3be00742a4a6f2a60286dbb7e4~mv2.jpg"], ["XPERION Hamburg", "/retail/xperion-hamburg", "https://static.wixstatic.com/media/97a2bb_ba0823eb9dcc48b7b7aee063cabf91d0~mv2.jpg"],
  ] },
  { number: "02", title: "Event design", href: "/event", intro: "Experiences designed to turn a moment into a lasting brand connection.", projects: [
    ["CES 2025", "/event/ces-2025", "https://static.wixstatic.com/media/97a2bb_42293a6eb1f94161ad08d9ac94e003c8~mv2.jpg"], ["Brasil Game Show", "/event/brasil-game-show-2023", "https://static.wixstatic.com/media/97a2bb_2ae9b9feb8bb4b8280f2df9d1c1b62d6~mv2.jpg"], ["ChinaJoy 2026", "/event/chinajoy-2026", "https://static.wixstatic.com/media/97a2bb_c870835d17ef4aaab2f7cc811c90f9d8~mv2.jpg"],
  ] },
  { number: "03", title: "Industrial design", href: "/industrial", intro: "Objects and product systems shaped around use, character and real-world production.", projects: [
    ["AERO", "/industrial/aero", "https://static.wixstatic.com/media/97a2bb_45ed5f1962c44fd9a3363fc89e58ce7a~mv2.jpg"], ["QIQ Mobility", "/industrial/qiq-mobility", "https://static.wixstatic.com/media/97a2bb_66dd921fddc647a9a89a9b435c37b346~mv2.jpg"], ["QIQ Pod", "/industrial/qiq-pod", "https://static.wixstatic.com/media/97a2bb_30a2c97a232647328d3c3e5b7f978aff~mv2.png"],
  ] },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [image, setImage] = useState(0);
  useEffect(() => { const timer = window.setInterval(() => setImage((current) => (current + 1) % heroImages.length), 9000); return () => window.clearInterval(timer); }, []);
  return <main>
    <section className="hero" id="work"><div className="heroMedia" aria-hidden="true">{heroImages.map((src, index) => <img key={src} className={index === image ? "visible" : ""} src={src} alt="" />)}</div><div className="heroShade" />
      <header className={`nav ${menuOpen ? "open" : ""}`}><a className="wordmark" href="#work">RYAN ANTONIUS</a><nav aria-label="Primary navigation"><a href="#work" onClick={() => setMenuOpen(false)}>WORK</a><a href="#contact" onClick={() => setMenuOpen(false)}>CONTACT</a><a href="#about" onClick={() => setMenuOpen(false)}>ABOUT</a></nav><button className="menu" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}><i /><i /></button></header>
      <div className="heroCopy"><p className="eyebrow">MULTIDISCIPLINARY DESIGNER</p><h1>Making brands<br />tangible.</h1><p className="categories">RETAIL DESIGN <b>·</b> EVENT DESIGN<br />INDUSTRIAL DESIGN <b>·</b> GRAPHIC DESIGN</p><a className="button light" href="#retail">VIEW SELECTED WORK <span>→</span></a></div>
    </section>
    <section className="intro"><p className="eyebrow">SELECTED WORK</p><p>Three practices. One approach: build considered experiences from the first idea through to the real world.</p></section>
    {disciplines.map((discipline) => <section className="discipline" id={discipline.title.split(" ")[0].toLowerCase()} key={discipline.title}><div className="disciplineHeading"><div><p className="eyebrow">{discipline.number} · SELECTED WORK</p><h2>{discipline.title}</h2></div><p>{discipline.intro}</p><a href={discipline.href}>VIEW ALL {discipline.title.toUpperCase()} <span>→</span></a></div><div className="rail">{discipline.projects.map(([name, href, src], index) => <a className="project" href={href} key={name}><img src={src} alt={name} /><div><span>{String(index + 1).padStart(2, "0")}</span><p><strong>{name}</strong><small>{discipline.title}</small></p><b>→</b></div></a>)}</div></section>)}
    <section className="capabilities"><p className="eyebrow">CAPABILITIES</p><div className="capabilityGrid"><article><span>01</span><h3>Concept & strategy</h3><p>Design strategy<br />Brand storytelling<br />Creative direction</p></article><article><span>02</span><h3>Design & visualisation</h3><p>Spatial design<br />Product design<br />3D modelling & rendering</p></article><article><span>03</span><h3>Development & execution</h3><p>Technical development<br />Material exploration<br />Production coordination</p></article><article><span>04</span><h3>Collaboration</h3><p>Cross-functional teams<br />Clients & stakeholders<br />End-to-end support</p></article></div></section>
    <section className="about" id="about"><img src="https://static.wixstatic.com/media/97a2bb_cfa93a1f5e8a4f78ad70dce924a3f9ad~mv2.jpg" alt="Ryan Antonius" /><div><p className="eyebrow">ABOUT</p><h2>Design is how<br />I connect ideas with<br />the physical world.</h2><p>I’m Ryan — a multidisciplinary designer working across retail experiences, event design and industrial design.</p><a className="button dark" href="#contact">GET IN TOUCH <span>→</span></a></div></section>
    <footer id="contact"><span>RYAN ANTONIUS © 2026</span><span>LINKEDIN &nbsp; / &nbsp; EMAIL &nbsp; / &nbsp; INSTAGRAM</span><a href="#work">BACK TO TOP ↑</a></footer>
  </main>;
}
